#include "DataSizes.h"

const Vector3 DataSizes::AIRPLANE_BODY_SIZE = {120, 550, 120};
const Vector3 DataSizes::AIRPLANE_WING_SIZE = {300, 10, 100};
const Vector3 DataSizes::AIRPLANE_RUDDER_SIZE = {150, 10, 70};
const Vector3 DataSizes::ENGINE_BASE_SIZE = {70, 100, 70};
const Vector3 DataSizes::ROCKET_SIZE = {15, 15, 15};
const int DataSizes::AIRPLANE_NUM_ROCKETS = 5;
const float DataSizes::AIRPLANE_SPEED = 25;
const float DataSizes::AIRPLANE_ROTATION = 80;


