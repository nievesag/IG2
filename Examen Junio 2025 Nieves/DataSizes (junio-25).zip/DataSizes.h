#ifndef DataSizes_h
#define DataSizes_h

#include "IG2Object.h"

class DataSizes{
    
public:    
        
    static const Vector3 AIRPLANE_BODY_SIZE;
    static const Vector3 AIRPLANE_WING_SIZE;
    static const Vector3 AIRPLANE_RUDDER_SIZE;
    static const Vector3 ENGINE_BASE_SIZE;
    static const Vector3 ROCKET_SIZE;
    static const int AIRPLANE_NUM_ROCKETS;
    static const float AIRPLANE_SPEED;
    static const float AIRPLANE_ROTATION;   
        
    
};
#endif /* DataSizes_h */
